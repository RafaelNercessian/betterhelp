$(document).ready(function () {
    var queryString = window.location.search;
    queryString = queryString.substring(1);
    var params = queryString.split('&');
    var orgId = '';
    var userId = '';
    $.each(params, function (i, param) {
        var parts = param.split('=');
        var key = parts[0];
        var value = parts[1];
        if (key === 'orgId') {
            orgId = value;
        } else if (key === 'userId') {
            userId = value;
        }
    });

    var data = {
        "userId": userId,
        "orgId": orgId
    }

    var settings = {
        "url": `https://api2.mightier.com/partner/bh/eligible?userId=${data.userId}&orgId=${data.orgId}`,
        "method": "GET",
        "timeout": 0,
    };

    $.ajax(settings).done(function (response) {
        console.log(response);
    });
})