$(document).ready(function () {
    $('#state').select2();

    $("#phone").mask("(999) 999-9999");


    //Form validation
    $('.form__details').validate({
        rules: {
            first_name: {
                required: true
            },
            email: {
                required: true,
                email: true
            },
            last_name: {
                required: true
            },
            address: {
                required: true
            },
            city: {
                required: true
            },
            zip: {
                required: true
            },
            phone: {
                required: true
            },
            accept: {
                required: true
            }
        },
        errorPlacement(error, element) {
            if (element.attr('name') === 'accept') {
                error.insertAfter($('#label__accept'));
            } else {
                error.insertAfter(element);
            }
        },
    });

    $('.form_input--submit').on('click', function (e) {
        e.preventDefault();
        if (!$('.form__details').valid()) {
            return false;
        }
        $('.form').hide();
        $('.submission').show();

        var data = {
            "first_name": $('#first_name').val(),
            "last_name": $('#last_name').val(),
            "email": $('#email').val(),
            "address": $('#address').val(),
            "apartment": $('#apartment').val(),
            "city": $('#city').val(),
            "state": $('#select2-state-container').attr('title'),
            "zip": $('#zip').val(),
            "phone": $('#phone').val(),
            "accept_mightier_terms": $('#accept').is(":checked"),
            "optin_marketin_email": $('#marketing').is(":checked"),
        }

        var settings = {
            "url": "https://api2.mightier.com/partner/bh/member",
            "method": "POST",
            "timeout": 0,
            "headers": {
              "Content-Type": "application/json"
            },
            "data": JSON.stringify(data),
          };
          
          $.ajax(settings).done(function (response) {
            console.log(response);
          });
    })
});